import AsyncStorage from '@react-native-async-storage/async-storage';

import type { AuthSession } from '@/types/auth';

const AUTH_SESSION_STORAGE_KEY = 'auth.session';
const ONBOARDING_ACTIVE_STORAGE_KEY = 'auth.onboarding-active';

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function isAuthSession(value: unknown): value is AuthSession {
  if (!isRecord(value)) {
    return false;
  }

  if (!isRecord(value.user) || !isRecord(value.tokens)) {
    return false;
  }

  return (
    typeof value.user.email === 'string' &&
    typeof value.user.role === 'string' &&
    typeof value.user.userName === 'string' &&
    typeof value.tokens.accessToken === 'string' &&
    typeof value.tokens.refreshToken === 'string'
  );
}

function parseAuthSession(value: string): AuthSession {
  const parsedValue: unknown = JSON.parse(value);

  if (!isAuthSession(parsedValue)) {
    throw new Error('Stored auth session has an invalid shape.');
  }

  return parsedValue;
}

export async function clearStoredAuthSession(): Promise<void> {
  await AsyncStorage.removeItem(AUTH_SESSION_STORAGE_KEY);
}

export async function readStoredAuthSession(): Promise<AuthSession | null> {
  const storedValue: string | null = await AsyncStorage.getItem(AUTH_SESSION_STORAGE_KEY);

  if (storedValue === null) {
    return null;
  }

  return parseAuthSession(storedValue);
}

export async function writeStoredAuthSession(session: AuthSession): Promise<void> {
  const serializedSession: string = JSON.stringify(session);

  await AsyncStorage.setItem(AUTH_SESSION_STORAGE_KEY, serializedSession);
}

export async function clearStoredOnboardingActive(): Promise<void> {
  await AsyncStorage.removeItem(ONBOARDING_ACTIVE_STORAGE_KEY);
}

export async function readStoredOnboardingActive(): Promise<boolean> {
  const storedValue: string | null = await AsyncStorage.getItem(ONBOARDING_ACTIVE_STORAGE_KEY);

  if (storedValue === null) {
    return false;
  }

  if (storedValue !== 'true' && storedValue !== 'false') {
    throw new Error('Stored onboarding state has an invalid shape.');
  }

  return storedValue === 'true';
}

export async function writeStoredOnboardingActive(isOnboardingActive: boolean): Promise<void> {
  const serializedValue: string = isOnboardingActive ? 'true' : 'false';

  await AsyncStorage.setItem(ONBOARDING_ACTIVE_STORAGE_KEY, serializedValue);
}
